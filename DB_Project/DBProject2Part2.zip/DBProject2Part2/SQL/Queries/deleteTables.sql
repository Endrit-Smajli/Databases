DROP TABLE publisher;
DROP TABLE libraryBranch;
DROP TABLE borrower;
DROP TABLE book;
DROP TABLE bookLoans;
DROP TABLE book_copies;
DROP TABLE book_authors;